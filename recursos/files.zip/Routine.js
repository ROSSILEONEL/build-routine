import mongoose from 'mongoose';
import { OBJETIVOS, TIPOS_ENTRENAMIENTO } from './User.js';

export const TECNICAS = [
  'normal',
  'dropset',
  'superserie',
  'biserie',
  'rest_pause',
  'al_fallo',
  'piramide',
  'tempo',
  'isometrico',
];

const ejercicioSchema = new mongoose.Schema(
  {
    nombre: { type: String, required: true, trim: true },
    series: { type: Number, required: true, min: 1, max: 10 },
    repeticiones: {
      min: { type: Number, required: true, min: 1 },
      max: { type: Number, required: true, min: 1 }, // 8-12 => min 8, max 12. Fijo: min = max
    },
    descansoSeg: { type: Number, required: true, min: 0, max: 600 },
    tecnica: { type: String, enum: TECNICAS, default: 'normal' },
    notas: { type: String, trim: true, maxlength: 300 },
    orden: { type: Number, required: true, min: 1 },
  },
  { _id: true }
);

const diaSchema = new mongoose.Schema(
  {
    nombre: { type: String, required: true, trim: true }, // "Día 1 - Espalda y bíceps"
    grupoMuscular: { type: String, trim: true },
    ejercicios: {
      type: [ejercicioSchema],
      validate: [(v) => v.length > 0, 'El día necesita al menos un ejercicio'],
    },
  },
  { _id: true }
);

// Cantidad de ejercicios: calculada, no guardada
diaSchema.virtual('cantidadEjercicios').get(function () {
  return this.ejercicios.length;
});

const routineSchema = new mongoose.Schema(
  {
    nombre: { type: String, required: true, trim: true, maxlength: 80 },
    descripcion: { type: String, trim: true, maxlength: 500 },
    nivel: {
      type: String,
      enum: ['principiante', 'intermedio', 'avanzado'],
      required: true,
    },
    objetivo: { type: String, enum: OBJETIVOS, required: true },
    tipoEntrenamiento: { type: String, enum: TIPOS_ENTRENAMIENTO, required: true },
    dias: {
      type: [diaSchema],
      validate: [(v) => v.length >= 1 && v.length <= 7, 'Entre 1 y 7 días'],
    },
    creadaPor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    publica: { type: Boolean, default: false },
  },
  { timestamps: true }
);

routineSchema.virtual('diasPorSemana').get(function () {
  return this.dias.length;
});

routineSchema.set('toJSON', { virtuals: true });
diaSchema.set('toJSON', { virtuals: true });

routineSchema.index({ nivel: 1, objetivo: 1, tipoEntrenamiento: 1 });

// Validación cruzada: repeticiones.min <= repeticiones.max
ejercicioSchema.pre('validate', function (next) {
  if (this.repeticiones.min > this.repeticiones.max) {
    return next(new Error('repeticiones.min no puede ser mayor que repeticiones.max'));
  }
  next();
});

export default mongoose.model('Routine', routineSchema);
