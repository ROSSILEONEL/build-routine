import mongoose from 'mongoose';
import bcrypt from 'bcrypt';

export const OBJETIVOS = [
  'hipertrofia',
  'fuerza',
  'perdida_de_grasa',
  'resistencia',
  'mantenimiento',
  'rendimiento_deportivo',
];

export const TIPOS_ENTRENAMIENTO = [
  'full_body',
  'torso_pierna',
  'push_pull_legs',
  'split_por_musculo',
  'funcional',
  'calistenia',
];

const userSchema = new mongoose.Schema(
  {
    nombre: {
      type: String,
      required: [true, 'El nombre es obligatorio'],
      trim: true,
      minlength: 2,
      maxlength: 60,
    },
    email: {
      type: String,
      required: [true, 'El email es obligatorio'],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, 'Email inválido'],
    },
    password: {
      type: String,
      required: [true, 'La contraseña es obligatoria'],
      minlength: 8,
      select: false, // no se devuelve en las consultas por defecto
    },
    fechaNacimiento: {
      type: Date,
      required: [true, 'La fecha de nacimiento es obligatoria'],
    },
    pesoKg: { type: Number, required: true, min: 30, max: 300 },
    alturaCm: { type: Number, required: true, min: 100, max: 250 },
    objetivos: {
      type: [{ type: String, enum: OBJETIVOS }],
      validate: [(v) => v.length > 0, 'Elegí al menos un objetivo'],
    },
    diasEntrenamiento: {
      type: Number,
      required: true,
      min: 1,
      max: 7,
    },
    tipoEntrenamiento: {
      type: String,
      enum: TIPOS_ENTRENAMIENTO,
      required: true,
    },
    nivel: {
      type: String,
      enum: ['principiante', 'intermedio', 'avanzado'],
      default: 'principiante',
    },
    rol: {
      type: String,
      enum: ['alumno', 'entrenador', 'admin'],
      default: 'alumno',
    },
  },
  { timestamps: true }
);

// Campos calculados: no se guardan, así nunca quedan desactualizados
userSchema.virtual('edad').get(function () {
  const hoy = new Date();
  let edad = hoy.getFullYear() - this.fechaNacimiento.getFullYear();
  const m = hoy.getMonth() - this.fechaNacimiento.getMonth();
  if (m < 0 || (m === 0 && hoy.getDate() < this.fechaNacimiento.getDate())) edad--;
  return edad;
});

userSchema.virtual('imc').get(function () {
  const m = this.alturaCm / 100;
  return Number((this.pesoKg / (m * m)).toFixed(1));
});

userSchema.set('toJSON', { virtuals: true });

// Hash de contraseña antes de guardar
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

userSchema.methods.compararPassword = function (passwordPlano) {
  return bcrypt.compare(passwordPlano, this.password);
};

export default mongoose.model('User', userSchema);
